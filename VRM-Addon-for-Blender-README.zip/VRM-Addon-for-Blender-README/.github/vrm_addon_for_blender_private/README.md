The source code for development is in the
<a href="https://github.com/saturday06/VRM-Addon-for-Blender/tree/main">`main`</a>
branch.
